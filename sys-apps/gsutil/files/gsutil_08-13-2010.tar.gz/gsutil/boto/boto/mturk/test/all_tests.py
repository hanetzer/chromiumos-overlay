import doctest

# doctest.testfile("create_hit.doctest")
# doctest.testfile("create_hit_binary.doctest")
doctest.testfile("create_free_text_question_regex.doctest")
# doctest.testfile("create_hit_from_hit_type.doctest")
# doctest.testfile("search_hits.doctest")
# doctest.testfile("reviewable_hits.doctest")
