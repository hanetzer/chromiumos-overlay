.. _ref-index:

=============
API Reference
=============

.. toctree::
   :maxdepth: 4

   boto
   cloudfront
   contrib
   ec2
   fps
   manage
   mapreduce
   mashups
   mturk
   pyami
   rds
   s3
   sdb
   services
   sns
   sqs
   vpc
   emr
