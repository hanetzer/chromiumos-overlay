.. _ref-sns:

====
SNS 
====

boto.sns
--------

.. automodule:: boto.sns
   :members:   
   :undoc-members:

